package starter.mobile;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.MobileBy;
import net.thucydides.core.annotations.Step;
import org.junit.Assert;
import org.openqa.selenium.By;
import test.automation.pageobject.BasePageObject;

public class Register extends BasePageObject {

    private By widgetButtonToRegister() {
        return MobileBy.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.widget.Button");
    }
    private By buttonRegister() {
        return MobileBy.xpath("//android.widget.Button[@content-desc=\"Register\"]");
    }
    private By fullNameField() {
        return MobileBy.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[1]");
    }
    private By emailField() {
        return MobileBy.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[2]");
    }
    private By passwordField() {
        return MobileBy.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[3]");
    }
    private By registerButton() {
        return MobileBy.xpath("//android.widget.Button[@content-desc=\"Register\"]");
    }

    private By headerProducts() {
//        return MobileBy.xpath("//android.view.View[@content-desc=\"Products\"]");
        return MobileBy.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View");
    }

    private By buttonAllertEmptyFullname() {
//        return MobileBy.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[1]");
        return MobileBy.xpath("//android.view.View[@content-desc=\"fullname can not empty\"]");
    }
    private By buttonAllertEmptyEmail() {
//        return MobileBy.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[2]");
        return MobileBy.xpath("//android.view.View[@content-desc=\"email can not empty\"]");
    }
    private By buttonAllertEmptyPassword() {
//        return MobileBy.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[3]");
        return MobileBy.xpath("//android.view.View[@content-desc=\"password can not empty\"]");
    }
    private By buttonAllert() {
        return MobileBy.xpath("//android.view.View[@content-desc=\"Gagal :(\"]");
    }

    @Step
    public void onTheHomepageToRegister() {
        Assert.assertTrue(waitUntilVisible(widgetButtonToRegister()).isDisplayed());
    }
    @Step
    public void clickWidgetButtonToRegister() {
        onClick(widgetButtonToRegister());
    }
    @Step
    public void clickButtonRegister() {
        onClick(buttonRegister());
    }
    @Step
    public void fullNameField(String fullName) {
        onClick(fullNameField());
        clear(fullNameField());
        waitUntilPresence(fullNameField()).sendKeys(fullName);
    }
    @Step
    public void enterEmail(String email) {
        onClick(emailField());
        clear(fullNameField());
        waitUntilPresence(emailField()).sendKeys(email);
    }
    @Step
    public void enterPassword(String password) {
        onClick(passwordField());
        clear(passwordField());
        waitUntilPresence(passwordField()).sendKeys(password);
    }
    @Step
    public void clickRegisterButton() {
        onClick(registerButton());
    }
    @Step
    public void successfullyRegister() {
        Assert.assertTrue(waitUntilVisible(headerProducts()).isDisplayed());
    }
    @Step
    public void failedRegister() {
        Assert.assertTrue(waitUntilVisible(buttonAllert()).isDisplayed());
    }
    @Step
    public void failedRegisterEmptyFullname() {
        Assert.assertTrue(waitUntilVisible(buttonAllertEmptyFullname()).isDisplayed());
    }
    @Step
    public void failedRegisterEmptyEmail() {
        Assert.assertTrue(waitUntilVisible(buttonAllertEmptyEmail()).isDisplayed());
    }
    @Step
    public void failedRegisterEmptyPassword() {
        Assert.assertTrue(waitUntilVisible(buttonAllertEmptyPassword()).isDisplayed());
    }

}
