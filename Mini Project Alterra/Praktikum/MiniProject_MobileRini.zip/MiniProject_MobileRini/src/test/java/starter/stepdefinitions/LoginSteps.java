package starter.stepdefinitions;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.mobile.Login;

public class LoginSteps {

    @Steps
    Login login;

    //Scenario: TC12 - Login with valid account
    @Given("I am on the homepage to login")
    public void onTheHomepageToLogin() {
        login.onTheHomepageToLogin();
    }
    @When("I click widget button to login")
    public void clickWidgetButtonToLogin() {
        login.clickWidgetButtonToLogin();
    }
    @And("I enter valid email")
    public void enterValidEmail() {
        login.enterValidEmail("rimzynh@mail.com");
    }
    @And("I enter valid password")
    public void enterValidPassword() {
        login.enterValidPassword("@Apaaja123");
    }
    @And("I click login button")
    public void clickLoginButton() {
        login.clickLoginButton();
    }
    @Then("I am successfully login")
    public void successfullyLogin() {
        login.successfullyLogin();
    }

    //Scenario: TC12 - Login with invalid email
    @Given("I am on homepage to login")
    public void onHomepageToLogin() {
        login.onTheHomepageToLogin();
    }
    @When("I click button to login")
    public void clickButtonToLogin() {
        login.clickWidgetButtonToLogin();
    }
    @And("I enter user valid email")
    public void enterUserValidEmail() {
        login.enterValidEmail("itayom@mail.com");
    }
    @And("I enter user valid password")
    public void enterUserValidPassword() {
        login.enterValidPassword("@Apaaja123");
    }
    @And("I click the login button")
    public void clickTheLoginButton() {
        login.clickLoginButton();
    }
    @Then("I am failed login")
    public void failedLogin() {
        login.failedLogin();
    }
}
