package starter.stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.mobile.Product;

public class ProductSteps {

    @Steps
    Product product;

    @Given("I am on the product list")
    public void onTheProductList() {

    }
    @When("I click button beli")
    public void clickButtonBeli() {
        product.clickButtonBeli();

    }
    @Then("Product successfully added to cart")
    public void productSuccessfullyAddedToCart() {
        product.verifyCartAdd();
    }
}
