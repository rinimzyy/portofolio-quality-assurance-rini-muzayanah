package starter.mobile;

import io.appium.java_client.MobileBy;
import net.thucydides.core.annotations.Step;

import org.junit.Assert;
import org.openqa.selenium.By;
import test.automation.pageobject.BasePageObject;

public class Login extends BasePageObject {

    private By widgetButtonToLogin() {
        return MobileBy.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.widget.Button");
    }
    private By emailFieldLogin() {
        return MobileBy.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[1]");
    }
    private By passwordFieldLogin() {
        return MobileBy.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.EditText[2]");
    }
    private By loginButton() {
        return MobileBy.xpath("//android.widget.Button[@content-desc=\"Login\"]");

    }
    private By headerProducts() {
        return MobileBy.accessibilityId("Products");
    }
    private By widgetButtonToLogout() {
        return MobileBy.xpath("/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[1]/android.widget.Button");
    }
    private By buttonAllertWithEmptyEmail() {
        return MobileBy.xpath("//android.view.View[@content-desc=\"email can not empty\"]");
    }
    private By buttonAllertWithEmptyPassword() {
        return MobileBy.xpath("//android.view.View[@content-desc=\"password can not empty\"]");
    }
    private By buttonAllert() {
        return MobileBy.xpath("//android.view.View[@content-desc=\"Email atau password tidak valid.\"]");
    }

    @Step
    public void onTheHomepageToLogin() {
        Assert.assertTrue(waitUntilPresence(widgetButtonToLogin()).isDisplayed());
    }
    @Step
    public void clickWidgetButtonToLogin() {
        onClick(widgetButtonToLogin());
    }
    @Step
    public void enterValidEmail(String email) {
        onClick(emailFieldLogin());
        waitUntilPresence(emailFieldLogin()).sendKeys(email);
    }
    @Step
    public void enterValidPassword(String password) {
        onClick(passwordFieldLogin());
        waitUntilPresence(passwordFieldLogin()).sendKeys(password);
    }
    @Step
    public void clickLoginButton() {
        onClick(loginButton());
    }
    @Step
    public void successfullyLogin() {
        Assert.assertTrue(waitUntilVisible(headerProducts()).isDisplayed());
    }
    @Step
    public void clickWidgetButtonToLogout() {
        onClick(widgetButtonToLogout());
    }
    @Step
    public void failedLogin() {
        Assert.assertTrue(waitUntilVisible(buttonAllert()).isDisplayed());
    }
}
