package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.mobile.Register;

public class RegisterSteps {

    @Steps
    Register register;

    //Scenario: MB001 - Register with valid account
    @Given("I am on the homepage to register")
    public void onTheHomepageToRegister() {
        register.onTheHomepageToRegister();
    }
    @When("I click widget button to register")
    public void clickWidgetButtonToRegister() {
        register.clickWidgetButtonToRegister();
    }
    @And("I click button register")
    public void clickButtonRegister() {
        register.clickButtonRegister();
    }
    @And("I enter fullname")
    public void enterFullname() {
        register.fullNameField("Rini Muzayanah");
    }
    @And("I enter email")
    public void enterEmail() {
        register.enterEmail("riniimobiletest4@mail.com");
    }
    @And("I enter password")
    public void enterPassword() {
        register.enterPassword("123123");
    }
    @And("I click register button")
    public void clickRegisterButton() {
        register.clickRegisterButton();
    }
    @Then("I am successfully register")
    public void successfullyRegister() {
        register.successfullyRegister();
    }

    //Scenario: MB001 - Register with registered email
    @Given("I am on homepage to register")
    public void onHomepageToRegister() {
        register.onTheHomepageToRegister();
    }
    @When("I click button to register")
    public void clickTheWidgetButtonToRegister() {
        register.clickWidgetButtonToRegister();
    }
    @And("I click the register button")
    public void clickTheButtonRegister() {
        register.clickButtonRegister();
    }
    @And("I enter user fullname")
    public void enterUserFullname() {
        register.fullNameField("Rini Muzayanah");
    }
    @And("I enter registered email")
    public void enterRegisteredEmail() {
        register.enterEmail("rinimobiletest2@mail.com");
    }
    @And("I enter user password")
    public void enterUserPassword() {
        register.enterPassword("123123");
    }
    @And("I click the register buttons")
    public void clickTheRegisterButton() {
        register.clickRegisterButton();
    }
    @Then("I am failed register")
    public void failedRegister() {
        register.failedRegister();
    }
}