package starter.stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.mobile.Login;

public class LogoutSteps {

    @Steps
    Login login;

    @Given("I am on the homepage")
    public void onTheHomepage() {
        login.onTheHomepageToLogin();
    }
    @When("I click widget button")
    public void clickWidgetButton() {
        login.clickWidgetButtonToLogin();
    }
    @And("I am already the login")
    public void enterEmailValidData() {
        login.enterValidEmail("rimzynh@mail.com");
        login.enterValidPassword("@Apaaja123");
        login.clickLoginButton();
        login.successfullyLogin();
    }
    @Then("I click logout button")
    public void clickLogoutButton() {
        login.clickWidgetButtonToLogout();
    }
}
