package starter.mobile;

import io.appium.java_client.MobileBy;
import net.thucydides.core.annotations.Step;
import org.junit.Assert;
import org.mockito.Mock;
import org.openqa.selenium.By;
import test.automation.pageobject.BasePageObject;

public class Product extends BasePageObject {

    private By buttonBeli() {
        return MobileBy.xpath("(//android.widget.Button[@content-desc=\"Beli\"])[1]");
    }
    private By buttonCart() {
        return MobileBy.xpath("//android.widget.Button[@content-desc=\"1\"]");
    }

    @Step
    public void clickButtonBeli() {
        onClick(buttonBeli());
    }
    @Step
    public void verifyCartAdd() {
        Assert.assertTrue(waitUntilVisible(buttonCart()).isDisplayed());
    }
}
